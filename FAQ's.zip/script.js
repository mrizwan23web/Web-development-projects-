const questions = document.querySelectorAll('.faq-question');

questions.forEach(btn => {
  btn.addEventListener('click', () => {
    const faqItem = btn.parentElement;
    const isActive = faqItem.classList.contains('active');

document.querySelectorAll('.faq-item').forEach(item => {
      item.classList.remove('active');
      item.querySelector('.faq-answer').classList.remove('open');
      item.querySelector('.icon').textContent = '➕';
    });

    if (!isActive) {
      faqItem.classList.add('active');
      faqItem.querySelector('.faq-answer').classList.add('open');
      faqItem.querySelector('.icon').textContent = '➖';
    }
  });
});
