// dark light theme toggle 
function toggleTheme() {
    document.body.classList.toggle('dark');
}

// scroll to Top Button
const topBtn = document.querySelector('.top-btn');
window.onscroll = function() {
    topBtn.style.display = window.scrollY > 300? 'block' : 'none';
};

function scrollToTop () {
    window.scrollTo({ top: 0, behavior: 'smooth'});
}