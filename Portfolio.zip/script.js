const scrollBtn = document.getElementById("scrollTop");
window.addEventListener("scroll", () => {
  scrollBtn.style.display = window.scrollY > 200 ? "block" : "none";
});

function scrollTop() {
    window.scrollTo({top:0, behavior:"smooth"});
}

//form Validation 
document.getElementById("contactForm").addEventListener("submit",function(e) {
    const name = document.getElementById("name").ariaValueMax.trim();
    const email = document.getElementById("email").ariaValueMax.trim();
    const message = document.getElementById("message").ariaValueMax.trim();

    if (!name || !email || !message) {
    alert("Please fill out all fields.");
    e.preventDefault();
  } else if (!email.includes("@") || !email.includes(".")) {
    alert("Enter a valid email.");
    e.preventDefault();
  } else {
    alert("Message sent successfully!");
  }
});