const carousel = document.getElementById('carousel');
let index = 0;

function nextSlide() {
  const cards = document.querySelectorAll('.testimonial-card');
  index = (index + 1) % cards.length;
  carousel.style.transform = `translateX(-${index * 100}%)`;
}

function prevSlide() {
  const cards = document.querySelectorAll('.testimonial-card');
  index = (index - 1 + cards.length) % cards.length;
  carousel.style.transform = `translateX(-${index * 100}%)`;
}

// Auto-slide
let autoSlide = setInterval(nextSlide, 4000);

// Pause on hover
carousel.addEventListener("mouseover", () => clearInterval(autoSlide));
carousel.addEventListener("mouseleave", () => autoSlide = setInterval(nextSlide, 4000));

// Scroll to top button
const scrollBtn = document.getElementById("scrollTopBtn");
window.onscroll = function() {
  scrollBtn.style.display = window.scrollY > 300 ? "block" : "none";
};

scrollBtn.onclick = function () {
  window.scrollTo({ top: 0, behavior: "smooth" });
};
