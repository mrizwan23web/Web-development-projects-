// scroll to top 
const scrollBtn = document.getElementById("scrollToTop");

window.addEventListener("scroll",()=>  {
    scrollBtn.style.display = window.scrollY >300 ? "block" : "none";
});

scrollBtn.addEventListener("click", ()=> {
    window.scrollTo({top: 0, behavior: smooth});
});

// Modal popup
function showModal(name, title, bio){
    document.getElementById("modalName").innerText = name;
    document.getElementById("modalTitle").innerText = title;
    document.getElementById("modalBio").innerText = bio;
    document.getElementById("profileModal").style.display ="flex";
}

function closeModal() {
    document.getElementById("profileModal").style.display = "none";
}